**cxgen**

v1.0.2.2 created by Armaan Aggarwal on May 26, 2019

This is a little python package that can generate a cx_Freeze setup.py script to 
turn your program into an .exe or .app file!

To know how to use this module, import cxgen and then call: 'cxgen.manual()'