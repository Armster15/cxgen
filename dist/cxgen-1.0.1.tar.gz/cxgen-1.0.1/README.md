cxgen 1.0

This is a little package that can generate a cx_Freeze setup.py script to 
turn your program into an .exe or .app file!

To know how to use this module, import cxgen and then call: 'cxgen.manual()'