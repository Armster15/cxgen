"""
cxgen 3.0.0
by Armaan Aggarwal
on March 9, 2020

It's been a while (like a year) 
but I have made some new (more like big) 
changes to cxgen!

- There is now a GUI! (cxgen will now be more focused on a GUI converter)
- cxgen stil uses the 2.0.0 framework, it's  just rebranded as cxgenLegacy
- Some changes to the framework so that it could support the GUI
- Python 2 is no longer supported - only Python versions 3+ are supported

HOW TO USE CXGEN

To run the GUI:
    from cxgen import GUI


"""